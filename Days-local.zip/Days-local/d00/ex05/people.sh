#!/bin/sh
ldapsearch -Q cn | grep 'cn: Z' | sort -fr | cut -c5-

