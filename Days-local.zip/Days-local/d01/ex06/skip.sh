ls -l | sed 'n;d'
