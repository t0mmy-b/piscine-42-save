#include <stdio.h>

int		ft_sqrt(int nb);

int main()
{
	printf("%d",ft_sqrt(2025000000));
	return 0;
}
