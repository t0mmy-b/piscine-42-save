#include <stdio.h>

int		ft_is_prime(int nb);

int		main()
{
	printf("%d",ft_is_prime(7));
	return 0;
}
