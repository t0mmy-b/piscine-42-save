/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tblochet <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/07 09:32:25 by tblochet          #+#    #+#             */
/*   Updated: 2018/09/13 11:34:49 by tblochet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		is_neg(char c)
{
	return (c == '-') ? -1 : 1;
}

int		ft_atoi(char *str)
{
	int i;
	int mult;
	int tt;

	i = 0;
	tt = 0;
	while ((0 <= str[i] && str[i] <= 32) || str[i] == ' ')
		i++;
	if (str[i] == '+' || str[i] == '-')
	{
		mult = is_neg(str[i]);
		if (str[i - 1] == '-' || str[i - 1] == '+')
			return (0);
		i++;
	}
	while (48 <= str[i] && str[i] <= 57)
	{
		tt = tt * 10 + (str[i] - '0');
		i++;
	}
	return (tt * mult);
}
