/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tblochet <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/13 11:55:38 by tblochet          #+#    #+#             */
/*   Updated: 2018/09/13 11:57:16 by tblochet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str)
{
	int i;

	i = 0;
	while (str[i])
	{
		if (str[i] >= 65 && str[i] <= 90)
			str[i] += 32;
		i--;
	}
	return (str);
}

int		ft_is_numeric(char c)
{
	return ((c >= '0' && c <= '9') ? 1 : 0);
}

int		ft_is_alpha(char c)
{
	return ((c >= 'a' && c <= 'z') ? 1 : 0);
}

int		ft_is_not_an(char c)
{
	return ((c <= ' ' || (c >= '!' && c <= '/')) ? 1 : 0);
}

char	*ft_strcapitalize(char *str)
{
	int i;

	i = 0;
	str = ft_strlowcase(str);
	if (ft_is_alpha(str[0]))
		str[0] -= 32;
	while (str[i] != '\0')
	{
		if (ft_is_alpha(str[i]) && (ft_is_not_an(str[i - 1])))
			str[i] -= 32;
		i++;
	}
	return (str);
}
