/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tblochet <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/09 10:50:02 by tblochet          #+#    #+#             */
/*   Updated: 2018/09/09 11:02:03 by tblochet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int			ft_strlen(char *str)
{
	int		i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int			ft_strcmp(char *s1, char *s2)
{
	int i;
	int j;

	i = ft_strlen(s1);
	j = ft_strlen(s2);
	if (i > j)
		return (1);
	if (i < j)
		return (-1);
	else
		return (0);
}
