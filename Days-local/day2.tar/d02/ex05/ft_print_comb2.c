/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tblochet <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/01 13:24:06 by tblochet          #+#    #+#             */
/*   Updated: 2018/09/01 17:10:22 by tblochet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_putchar(char c)
{
	write(1, &c, 1);
}

void ft_print_comb2()
{
	int ns[4];
	
	ns[0] = '0';
	ns[1] = '0';
	ns[2] = '0';
	ns[3] = '0';

	while (ns[0] <= '9')
	{
		ns[3]++;
		if (ns[3] > '9')
		{
			ns[2]++;
			ns[3] = '0';
		}
		if (ns[2] > '9')
		{
			ns[1]++;
			ns[2] = '0';
		}
		if (ns[1] > '9')
		{
			ns[0]++;
			ns[1] = '0';
		}
		ft_putchar(ns[0]);
		ft_putchar(ns[1]);
		ft_putchar(' ');
		ft_putchar(ns[2]);
		ft_putchar(ns[3]);
		ft_putchar(',');
		ft_putchar(' ');
	}
}

int main()
{
	ft_print_comb2();
}
