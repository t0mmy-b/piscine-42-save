/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tblochet <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/08 14:43:57 by tblochet          #+#    #+#             */
/*   Updated: 2018/09/09 10:24:18 by tblochet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int			ft_strlen(char *str)
{
	int		i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

char		*ft_strstr(char *str, char *to_find)
{
	int i;
	int j;

	i = 0;
	j = 0;
	while (str[i] != to_find[j])
	{
		j++;
		if (j == ft_strlen(to_find))
		{
			j = 0;
			i++;
			if (i > ft_strlen(str))
				break ;
		}
	}
	while (str[i] == to_find[j])
	{
		if (str[i + 1] != to_find[j + 1])
			break ;
	}
}
