/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tblochet <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/08 10:51:05 by tblochet          #+#    #+#             */
/*   Updated: 2018/09/08 11:45:14 by tblochet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int			ft_strlen(char *str)
{
	int		i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

void		ft_strcpy(char *dest, char *src)
{
	int i;
	int str_len;

	i = 0;
	str_len = ft_strlen(src);
	while (i <= str_len)
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
}
