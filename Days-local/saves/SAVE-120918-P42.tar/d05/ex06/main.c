#include <stdio.h>

char	*ft_strcmp(char *s1, char *s2);

int main()
{
	printf("%s",ft_strcmp("Coucou","coucou"));
	return 0;
}
