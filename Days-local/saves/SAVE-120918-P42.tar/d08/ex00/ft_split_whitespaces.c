/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tblochet <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/09/10 09:38:04 by tblochet          #+#    #+#             */
/*   Updated: 2018/09/11 10:04:51 by tblochet         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		word_count(char *str)
{
	int i;
	int word_number;

	while (str[i])
	{
		if (str[i] <= 32)
		{
			word_number++;
			i++;
		}
		i++;
	}
}

char	**ft_split_whitespaces(char *str)
{
	
}
